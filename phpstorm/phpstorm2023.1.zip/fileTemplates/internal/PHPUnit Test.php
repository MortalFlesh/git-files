<?php declare(strict_types=1);
#if (${NAMESPACE})

namespace ${NAMESPACE};
#end

/**
 * @group unit
 */
class ${NAME} extends AbstractTestCase
{
    public function testIncomplete() {
        $this->markTestIncomplete('todo');
    }
}
