/** ${TYPE_TAG} ${TYPE_HINT} */
