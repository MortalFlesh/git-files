public function set${NAME}($${PARAM_NAME}): self
{
    $this->${FIELD_NAME} = $${PARAM_NAME};

    return $this;
}
