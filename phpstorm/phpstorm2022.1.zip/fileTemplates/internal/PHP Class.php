<?php declare(strict_types=1);
#if (${NAMESPACE})

namespace ${NAMESPACE};
#end

class ${NAME}
{

}
