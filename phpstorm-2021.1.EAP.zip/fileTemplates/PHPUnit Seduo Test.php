<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};
#end

use Mockery as m;
use Seduo\Core\Tests\SeduoTestCase;

class ${NAME} extends SeduoTestCase
{
    public function testIncomplete() {
        \$this->markTestIncomplete('todo');
    }
}
