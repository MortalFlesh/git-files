<?php
#if (${NAMESPACE})

namespace ${NAMESPACE};
#end

use Doctrine\ORM\EntityRepository;

class ${NAME} extends EntityRepository
{
}
